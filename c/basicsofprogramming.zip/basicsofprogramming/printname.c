#include<stdio.h>
int main (){

    printf("My name is :  Arkapriya das\n" "course:  bsc\n" "college:  iaer\n" "1st semester\n" "roll: blah blah blah");
    printf("\n100+100=200 , 100");
    return 0;
}