#include <stdio.h>
int main(){
    printf("arkapruoiya das \n,iaer,bsc cybersecurity");
    return 0;
}