#include <stdio.h>
int main(){
    char a;
    printf ("Put your college name :");
    scanf("%s",&a);
    
    printf("This is your college name is  ",a);

    return 0;
}