#include <stdio.h>
int main (){
int a;
printf("Give number :");
scanf("%d",&a);
printf("The sum of to numbers are %d \n:", a+a);

printf("The substraction of to numbers are %d\n :", a-a);
printf("The multiplication of to numbers are %d\n :", a*a);
printf("The div of to numbers are %d\n :", a/a);
return 0;



}