#include <stdio.h>
int main (){
    int a;
    printf("Enter a number");
    scanf("%d",&a);
    printf("The number you have entered :%d",a);
    return 0;


}