#include<stdio.h>
int main(){
    int a;
   

    printf("Put your number :\n");
    scanf("%d",&a );
    printf("The number is being :%d\n\t",a+a);//a+a 5+5 =10, a=5
    printf("The number is being :%d\n\t",a-a);
    printf("The number is being :%d\n\t",a*a);
    printf("The number is being :%d\n\t",a/a);
   

    return 0;
}