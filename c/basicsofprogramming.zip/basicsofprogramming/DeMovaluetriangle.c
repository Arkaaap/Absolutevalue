#include<stdio.h>
int main()
{

    int x,y,a;

    printf("Enter the two values of the triangle ");
    scanf("%d%d",&x&y );
    a=180-(x+y);
    printf("Here is your result :%d", a);
    return 0;

}