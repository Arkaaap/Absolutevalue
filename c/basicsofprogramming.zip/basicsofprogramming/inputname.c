#include <stdio.h>
int main(){
    char a,Z;
    printf("What is your name :");
    scanf("%s",&a);
    printf("Your name is written here. ",a);

    return 0;
} 